const shopMinisConfig = require("@shopify/shop-minis-react/eslint/config");

module.exports = [shopMinisConfig];
